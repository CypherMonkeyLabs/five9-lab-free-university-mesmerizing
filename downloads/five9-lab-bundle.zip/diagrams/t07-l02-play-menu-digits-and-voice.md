# Play, Menu, digits, and voice

- The failure exit is part of the design.

## Sources and go deeper

- [IVR modules](https://documentation.five9.com/bundle/ivr-admin/page/ivr-admin/modules/_ch-modules.htm). vendor. last checked 2026-10.
- [Menu module](https://documentation.five9.com/bundle/ivr-admin/page/ivr-admin/modules/menu-module.htm). vendor. last checked 2026-10.
- [XML web service IVR example](https://documentation.five9.com/bundle/ivr-admin/page/ivr-admin/examples/creating-ivr-script-xml-web-service-query.htm). vendor. last checked 2026-10.
- [RFC 4733](https://www.rfc-editor.org/rfc/rfc4733). rfc. last checked 2026-10.
- [Interactive voice response](https://en.wikipedia.org/wiki/Interactive_voice_response). wikipedia. last checked 2026-10.
