# A skill is a queue with people in it

- From the skill group topic.

## Sources and go deeper

- [Skill groups](https://documentation.five9.com/bundle/basic-admin/page/basic-admin/skill-groups/_ch-skill-groups.htm). vendor. last checked 2026-10.
