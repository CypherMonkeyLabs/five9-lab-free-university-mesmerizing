# NLP in the IVR is not the same as Studio

- Do not swap the names.

## Sources and go deeper

- [IVR modules](https://documentation.five9.com/bundle/ivr-admin/page/ivr-admin/modules/_ch-modules.htm). vendor. last checked 2026-10.
- [Studio digital IVA with VCC](https://community.five9.com/s/article/Studio-7-Integrate-Digital-IVA-in-Studio-with-VCC?language=en_US). community. last checked 2026-10.
- [Interactive voice response](https://en.wikipedia.org/wiki/Interactive_voice_response). wikipedia. last checked 2026-10.
