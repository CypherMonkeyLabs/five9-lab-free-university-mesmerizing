# Transcription and assist are features you turn on

- Features, not a secret model name.

## Sources and go deeper

- [Five9 Engage](https://www.five9.com/platform/self-service-and-engagement). vendor. last checked 2026-10.
- [GenAI Studio](https://www.five9.com/products/capabilities/gen-ai-studio). vendor. last checked 2026-10.
- confirm. GenAI Studio is described as engine-agnostic. This lab does not name the default model for a new domain.. last checked 2026-10.
