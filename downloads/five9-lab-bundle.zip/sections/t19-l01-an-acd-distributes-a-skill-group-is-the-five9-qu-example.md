# An ACD distributes. A skill group is the Five9 queue · Worked example

- Write one Wikipedia sentence and one Five9 sentence.
- Name the ACD idea
- Name the skill group
- Do not invent a routing algorithm
- Each sentence has its own page.

## Sources and go deeper

- [Automatic call distributor](https://en.wikipedia.org/wiki/Automatic_call_distributor). wikipedia. last checked 2026-10.
- [Skill groups](https://documentation.five9.com/bundle/basic-admin/page/basic-admin/skill-groups/_ch-skill-groups.htm). vendor. last checked 2026-10.
- [Interactive voice response](https://en.wikipedia.org/wiki/Interactive_voice_response). wikipedia. last checked 2026-10.
