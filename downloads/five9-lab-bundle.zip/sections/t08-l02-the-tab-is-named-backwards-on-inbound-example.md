# The tab is named backwards on inbound · Worked example

- Write the tab name under each.
- Inbound
- Outbound
- Autodial
- Inbound and autodial match.

## Sources and go deeper

- [Skill groups](https://documentation.five9.com/bundle/basic-admin/page/basic-admin/skill-groups/_ch-skill-groups.htm). vendor. last checked 2026-10.
- [RFC 3261, SIP: Session Initiation Protocol](https://www.rfc-editor.org/rfc/rfc3261). rfc. last checked 2026-10.
