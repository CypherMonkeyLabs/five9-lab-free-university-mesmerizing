# The script is the inbound product · Visual

- From the inbound campaign topic.

## Sources and go deeper

- [Inbound campaigns](https://documentation.five9.com/bundle/campaign-admin/page/campaign-admin/creating-campaigns/types-of-campaigns/inbound-campaigns.htm). vendor. last checked 2026-10.
- [Skill Transfer functions](https://community.five9.com/s/article/Administrator-IVR-Skill-Transfer-Module-Functions-and-Features). community. last checked 2026-10.
- [Interactive voice response](https://en.wikipedia.org/wiki/Interactive_voice_response). wikipedia. last checked 2026-10.
- confirm. A post-call survey exists as a campaign-admin topic title in the docs tree. This lesson does not describe its screens. Open that topic before you design one. last checked 2026-10.
