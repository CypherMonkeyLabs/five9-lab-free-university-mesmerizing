# University is a catalog, not a secret exam code · Worked example

- Write what you can say about administrator training and what you will not say.
- Assessments exist
- No code
- The brief's date
- The fake code is absent.

## Sources and go deeper

- [Five9 University](https://www.five9.com/contact-center-services/training). vendor. last checked 2026-10.
- [Administrator training classes](https://community.five9.com/s/article/Five9-University-Five9-Administrator-Training-Classes?language=en_US). community. last checked 2026-10.
- [University curriculum brief, April 2023](https://www.five9.com/sites/default/files/2023-04/Five9_University_Curriculum_Brief_v5.pdf). vendor. last checked 2026-10.
- confirm. The curriculum brief is from April 2023. Course lists move. This lab found no public administrator exam code to quote. last checked 2026-10.
