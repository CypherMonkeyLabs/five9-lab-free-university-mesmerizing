# A list is not a campaign · Worked example

- Name the column that becomes number1.
- Pick the phone column
- Say the campaign type
- Say the state required before dialing
- You did not attach the file to an inbound campaign.

## Sources and go deeper

- [List dialing modes](https://community.five9.com/s/article/Administrator-List-Dialing-Modes-and-its-Differences?language=en_US). community. last checked 2026-10.
- [Managing campaign dispositions](https://documentation.five9.com/bundle/campaign-admin/page/campaign-admin/configuring-campaigns/configuring-dispositions/managing-dispositions.htm). vendor. last checked 2026-10.
